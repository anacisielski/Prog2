import os
from peewee import *
from flask import Flask, json, jsonify
from playhouse.shortcuts import model_to_dict

arq = 'pronto_socorro.db'
db = SqliteDatabase (arq )

class BaseModel(Model):
    class Meta:
        database = db

class Doenca(BaseModel):
    nome_doenca = CharField()
    sintomas = CharField()

class Paciente(BaseModel):
    nome = CharField()
    telefone = CharField()
    cpf = CharField()
    idade = IntegerField()
    problema = ForeignKeyField(Doenca)

class Atendente(BaseModel):
    nome = CharField()
    cpf = CharField()
    turno = CharField()

class Tratamento(BaseModel):
    nome_tratamento = CharField()
    desc_tratamento = CharField()
    periodo_utilizacao = CharField()

class Medico(BaseModel):
    nome = CharField()
    cod_identificacao = IntegerField()
    area_atuacao = CharField()
    horario_disp = CharField()

class Tratamento_Doenca(BaseModel):
    data_inicio = CharField()
    medico = ForeignKeyField(Medico)
    doenca = ForeignKeyField(Doenca)
    tratamento = ForeignKeyField(Tratamento)

class Exame(BaseModel):
    nome_exame = CharField()
    valor = FloatField()

class Requisicao(BaseModel):
    data = CharField()
    cod_requisicao = IntegerField()
    paciente = ForeignKeyField(Paciente)
    medico = ForeignKeyField(Medico)

class ExameRequisicao(BaseModel):
    prazo_diagnostico = CharField()
    exame = ForeignKeyField(Exame)
    requisicao = ForeignKeyField(Requisicao)

class BalcaoAtendimento(BaseModel):
    local = CharField()
    atendente = ForeignKeyField(Atendente)
    num_atendimentos = IntegerField()
    exame_requisitado = ForeignKeyField(ExameRequisicao)

db.connect()
db.create_tables([Paciente, Atendente, Tratamento, Doenca, Medico, Tratamento_Doenca, Exame, Requisicao, ExameRequisicao, BalcaoAtendimento])

doenca = Doenca.create(nome_doenca = "Pneumonia", sintomas = "Dor nos Pulmões, Dificuldades para Respirar, Desmaios")
paciente = Paciente.create(nome = "Ana Julia", telefone = "(47)999652768", cpf = "12345678901", idade = 17, problema = doenca)
atendente = Atendente.create(nome = "Lexie Grey", cpf = "09876543210", turno = "Noturno")
tratamento = Tratamento.create(nome_tratamento = "Antibiótico - Pneumonia", desc_tratamento = "Aplicar a dosagem recomendada de antibiótico durante o período designado (obs: Dosagem e período variam de acordo com a idade)", periodo_utilizacao = "mínimo 5 dias")
medico = Medico.create(nome = "Derek Shepherd", cod_identificacao = 10, area_atuacao = "Neurologista", horario_disp = "plantão de 48 horas")
trat_doenca = Tratamento_Doenca.create(data_inicio = "09/01/2019", medico = medico, doenca = doenca, tratamento = tratamento)
exame = Exame.create(nome_exame = "Raio-X", valor = 120.00)
requisicao = Requisicao.create(data = "01/12/2019", cod_requisicao = 412345, paciente = paciente, medico = medico)
exameRequisicao = ExameRequisicao.create(prazo_diagnostico = "10 min", exame = exame, requisicao = requisicao)
balcao = BalcaoAtendimento.create(local = "Lado esquerdo da Entrada Principal", atendente = atendente, num_atendimentos = 666, exame_requisitado = exameRequisicao)

json = list(map(model_to_dict, BalcaoAtendimento.select()))
print(json)